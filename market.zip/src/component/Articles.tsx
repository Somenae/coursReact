import ArticlesInterface from "../interfaces/ArticlesInterface";
interface ArticlesProps {
  article: ArticlesInterface;
  onClickDelete: (article: ArticlesInterface) => void;
  onClickDisplayUpdateForm: () => void;
  onClickSubmit: (label:HTMLInputElement, price:HTMLInputElement, year:HTMLInputElement) => void;
}
const Articles: React.FC<ArticlesProps> = ({ article, onClickDelete, onClickDisplayUpdateForm, onClickSubmit }) => {
  return (
    <section className="d-flex justify-content-between my-3">
      <h2 className="h4">{article.label}</h2>
      <div>
        <button
          onClick={() => {
            onClickDisplayUpdateForm();
          }}
          className="btn btn-warning me-3"
        >Modifier
        </button>

        <form onSubmit={(event) => {
        event.preventDefault();
        const labelArticle = document.getElementById('input-toy') as HTMLInputElement;
        const priceArticle = document.getElementById('input-price') as HTMLInputElement;
        const yearArticle = document.getElementById('input-année') as HTMLInputElement;
        if (labelArticle && priceArticle && yearArticle) {
          onClickSubmit(labelArticle, priceArticle, yearArticle);
        }
      }}
        className='d-flex gap-2 visually-hidden formUpdate'>
        <label htmlFor='input-toy' className='visually-hidden'>Label jouet</label>
        <input type="text" id="input-toy" placeholder='Nom du jouet'/>

        <label htmlFor='input-price' className='visually-hidden'>Prix jouet</label>
        <input type="number" id="input-price" placeholder='Prix du jouet'/>

        <label htmlFor='input-toy' className='visually-hidden'>Année jouet</label>
        <input type="text" id="input-année" placeholder='Année du jouet'/>

        <button type='submit' className='btn btn-success'>Ajouter</button>
      </form>

        <button
          onClick={() => {
            onClickDelete(article);
          }}
          className="btn btn-danger me-3"
        >Supprimer
        </button>
      </div>
    </section>
  );
};

export default Articles;
