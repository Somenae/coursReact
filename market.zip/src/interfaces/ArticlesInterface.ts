export default interface ArticlesInterface {
  label: string;
  price: number;
  id: number;
  year: string;
}